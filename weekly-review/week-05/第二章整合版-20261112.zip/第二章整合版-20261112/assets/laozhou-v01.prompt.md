Generated with built-in image generation. Reference: existing pkg-case/assets/portraits/old-guard-full.png, confirmed against the supplied character table and chapter asset document.

Create a transparent waist-up elderly Hong Kong Chinese male witness sprite. Preserve the reference's lean face, thin moustache, peaked cap, short-sleeved collared shirt, chest pockets, epaulettes and quiet hands-behind-back pose. Neutral cooperative expression. Geometric flat noir comic illustration, clear black #181715 contours, angular gray shadows and warm paper #EEE8DB highlights. Consistent collar line weights and natural head-to-torso proportions. No colored skin tint, no scene, text or frame. Transparent background. Simplify for mobile dialogue use. No new story props.

Runtime PNG resized with alpha preserved to 440x611; 249068 bytes. No new expression variants generated. Uniform retained from the supplied existing design; current story context remains a voluntary witness meeting, not duty.
