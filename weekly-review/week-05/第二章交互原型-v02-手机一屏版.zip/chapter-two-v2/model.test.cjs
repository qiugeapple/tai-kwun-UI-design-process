const assert=require('node:assert/strict');
const M=require('./model.js');
const s=M.fresh();
// A wrong attempt cannot advance or award a record.
assert.equal(M.check(s).ok,false);assert.equal(s.p21.step,0);assert.deepEqual(s.earned,[]);
for(const [id,i] of [['a',0],['b',1],['c',2]])M.placeTestimony(s,id,i);
assert.equal(M.check(s).ok,true);assert.equal(s.p21.step,1);
s.p21.link=0;assert.equal(M.check(s).ok,false);assert.deepEqual(s.earned,[]);
s.p21.link=1;assert.equal(M.check(s).ok,true);
s.p21.answer='proved';assert.equal(M.check(s).ok,false);
s.p21.answer='uncertain';assert.equal(M.check(s).complete,true);assert.deepEqual(s.earned,['D02']);
// Rechecking a completed result cannot duplicate rewards.
M.check(s);assert.deepEqual(s.earned,['D02']);
assert.equal(M.relationValid(['mei','chen'],'friend'),true);
assert.equal(M.relationValid(['ruan','he'],'dispute'),true);
assert.equal(M.relationValid(['chen','he'],'friend'),false);
s.node=1;s.p22.links=[{pair:['chen','mei'],relation:'friend'},{pair:['he','ruan'],relation:'dispute'}];
assert.equal(M.check(s).ok,true);
s.p22.questions=['identity','guilt'];assert.equal(M.check(s).ok,false);
s.p22.questions=['contact','where'];assert.equal(M.check(s).complete,true);
s.node=2;s.p23.placed={register:'shipyard',shift:'hospital',claim:'claim'};assert.equal(M.check(s).ok,false);
s.p23.placed={register:'hospital',shift:'shipyard',claim:'claim'};assert.equal(M.check(s).ok,true);
s.p23.gap=true;s.p23.materials=['register','medicine'];assert.equal(M.check(s).ok,false);
s.p23.materials=['treatment','staff'];assert.equal(M.check(s).complete,true);
assert.deepEqual(s.done,[0,1,2]);assert.deepEqual(s.earned,['D02','relation','D03']);
const restored=JSON.parse(JSON.stringify(s));assert.deepEqual(restored,s);
const swapped=M.fresh();M.placeTestimony(swapped,'a',0);M.placeTestimony(swapped,'b',1);M.placeTestimony(swapped,'a',1);assert.deepEqual(swapped.p21.slots,['b','a',null]);
console.log('PASS: wrong answers, progression, reward deduplication, relation validation, timeline gaps, serialization, slot swapping');
