(function(g){
'use strict';
const testimony={a:'现场只看到一个模糊的人影，没能辨认身份。',b:'后来听说，何志强与阮文雄之间有工资纠纷。',c:'因此把当时的人影与阮文雄联系起来。'};
const people={he:'何志强',chen:'陈小梅',ruan:'阮文雄',mei:'阮氏梅'};
const questions={contact:'陈小梅在案发前后与阮家有何接触？',where:'关键时段阮文雄在哪里？',identity:'有工资纠纷，是否就能确认人影身份？',guilt:'与当事人相识，是否就能认定参与冲突？'};
const materials={register:'医院挂号记录',treatment:'连续治疗记录',medicine:'取药记录',staff:'医护人员确认'};
const records={D02:{title:'D02 · 人影身份仍待核实',text:'现场未能认出人影。与阮文雄的关联来自事后获知的纠纷，不能据此确认他当时在场。'},relation:{title:'人物关系调查记录',text:'已整理陈小梅与阮氏梅的朋友关系，以及何志强与阮文雄的工作纠纷。继续核查陈小梅与阮家的接触、阮文雄的去向；关系本身不能证明参与致命冲突。'},D03:{title:'D03 · 时间缺口仍需核实',text:'挂号记录只能证明到过医院，无法证明全程在院。需要连续治疗记录与医护人员确认；当前材料尚不足以形成完整不在场证明。'}};
function fresh(){return {version:1,view:'home',node:0,done:[],earned:[],p21:{step:0,slots:[null,null,null],selected:null,link:null,answer:null,errors:0},p22:{step:0,pair:[],relation:null,links:[],questions:[],errors:0},p23:{step:0,placed:{},selected:null,gap:false,materials:[],errors:0}};}
const pairKey=pair=>pair.slice().sort().join('|');
function relationValid(pair,relation){return (pairKey(pair)==='chen|mei'&&relation==='friend')||(pairKey(pair)==='he|ruan'&&relation==='dispute');}
function placeTestimony(s,id,index){if(!(id in testimony)||index<0||index>2)return;const old=s.p21.slots.indexOf(id),occupant=s.p21.slots[index];if(old>=0)s.p21.slots[old]=occupant;s.p21.slots[index]=id;s.p21.selected=null;}
function check(s){
const n=s.node,p=s['p2'+(n+1)];let ok=false,message='';
if(n===0){if(p.step===0){ok=p.slots.join(',')==='a,b,c';message='先区分现场观察、事后听闻，以及由此作出的身份联想。';}else if(p.step===1){ok=p.link===1;message='哪一步把听闻的纠纷，变成了对人影身份的判断？';}else{ok=p.answer==='uncertain';message='现场没有辨认出身份，事后关联仍需核实。';}}
if(n===1){if(p.step===0){ok=p.links.length===2&&p.links.every(l=>relationValid(l.pair,l.relation))&&new Set(p.links.map(l=>pairKey(l.pair))).size===2;message='先整理两组有材料支持的关系。';}else{ok=p.questions.length===2&&p.questions.includes('contact')&&p.questions.includes('where');message='请选择能继续通过走访或材料核查的问题，避免把关系直接等同于结论。';}}
if(n===2){if(p.step===0){ok=p.placed.register==='hospital'&&p.placed.shift==='shipyard'&&p.placed.claim==='claim';message='区分医院的到访时间点、船厂的代班区间，以及待核实的目击说法。';}else{ok=p.gap&&p.materials.length===2&&p.materials.includes('treatment')&&p.materials.includes('staff');message='单个时间点不能覆盖整个时段。需要能连续覆盖时段，并可独立核对的材料。';}}
if(!ok){p.errors++;return {ok:false,message};}
if(p.step<(n===0?2:1)){p.step++;return {ok:true,complete:false};}
const id=['D02','relation','D03'][n];if(!s.earned.includes(id))s.earned.push(id);if(!s.done.includes(n))s.done.push(n);s.view='result';return {ok:true,complete:true};
}
const api={fresh,testimony,people,questions,materials,records,pairKey,relationValid,placeTestimony,check};
if(typeof module!=='undefined')module.exports=api;else g.ChapterTwo=api;
})(typeof window==='undefined'?globalThis:window);
